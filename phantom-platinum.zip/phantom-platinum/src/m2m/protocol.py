# Implementação base do protocolo M2M
