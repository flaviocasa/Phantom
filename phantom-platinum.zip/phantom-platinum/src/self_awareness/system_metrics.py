# Métricas de auto-desempenho
