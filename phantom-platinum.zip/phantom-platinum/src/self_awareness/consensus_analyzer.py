# Análise de padrões de consenso
