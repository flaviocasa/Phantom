# Evolução da ontologia Gnosis
