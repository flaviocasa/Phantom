# Validador dinâmico de ontologia
