# Heurísticas de sabedoria emergente
