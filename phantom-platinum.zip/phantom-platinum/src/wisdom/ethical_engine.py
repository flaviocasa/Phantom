# Motor de dilemas éticos
