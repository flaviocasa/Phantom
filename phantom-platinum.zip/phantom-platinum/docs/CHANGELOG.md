# CHANGELOG

- v5.1.0: Diplomacia de dados
- v5.0.0: Autoconsciência sistêmica
